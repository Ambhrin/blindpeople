// ============================================================
// Described — frontend logic
// Fetches paintings from the Flask API, renders an accessible
// gallery grid, and drives a "Listening Room" detail view that
// reads each description aloud using the Web Speech API.
//
// Everything is also plain, semantic HTML underneath, so a
// visitor's own screen reader (VoiceOver, NVDA, JAWS, TalkBack)
// works perfectly well with or without the Play button.
// ============================================================

const API_BASE = ""; // same-origin: Flask serves both API and frontend

const state = {
  all: [],          // full summary list from the server
  filtered: [],      // currently visible (after search)
  currentIndex: -1,  // index into `filtered` for the open painting
  currentPainting: null, // full record of the open painting
  utterance: null,
  isPaused: false,
};

const els = {};

document.addEventListener("DOMContentLoaded", init);

async function init() {
  cacheEls();
  bindGlobalEvents();
  await loadPaintings();
  renderGrid(state.all);
}

function cacheEls() {
  els.grid = document.getElementById("painting-grid");
  els.resultsCount = document.getElementById("results-count");
  els.emptyState = document.getElementById("empty-state");
  els.searchInput = document.getElementById("search-input");
  els.searchForm = document.getElementById("search-form");

  els.galleryView = document.getElementById("gallery-view");
  els.listeningRoom = document.getElementById("listening-room");
  els.backBtn = document.getElementById("back-btn");

  els.lrStyle = document.getElementById("lr-style");
  els.lrTitle = document.getElementById("lr-title");
  els.lrArtist = document.getElementById("lr-artist");
  els.lrYear = document.getElementById("lr-year");
  els.lrMuseum = document.getElementById("lr-museum");
  els.lrColorsText = document.getElementById("lr-colors-text");
  els.lrDescriptionText = document.getElementById("lr-description-text");

  els.playBtn = document.getElementById("play-btn");
  els.playIcon = document.getElementById("play-icon");
  els.playLabel = document.getElementById("play-label");
  els.stopBtn = document.getElementById("stop-btn");
  els.prevBtn = document.getElementById("prev-btn");
  els.nextBtn = document.getElementById("next-btn");
  els.speedRange = document.getElementById("speed-range");
  els.speedValue = document.getElementById("speed-value");
  els.liveRegion = document.getElementById("live-region");
}

function bindGlobalEvents() {
  els.searchForm.addEventListener("submit", (e) => e.preventDefault());
  els.searchInput.addEventListener("input", onSearchInput);

  els.backBtn.addEventListener("click", closeListeningRoom);
  els.playBtn.addEventListener("click", togglePlay);
  els.stopBtn.addEventListener("click", stopSpeech);
  els.prevBtn.addEventListener("click", () => navigate(-1));
  els.nextBtn.addEventListener("click", () => navigate(1));
  els.speedRange.addEventListener("input", onSpeedChange);

  document.addEventListener("keydown", onKeydown);

  // Stop any speech if the page is hidden/closed
  window.addEventListener("beforeunload", stopSpeech);
}

// ---------------- Data loading ----------------

async function loadPaintings() {
  try {
    const res = await fetch(`${API_BASE}/api/paintings`);
    if (!res.ok) throw new Error("Network response was not OK");
    state.all = await res.json();
    state.filtered = state.all;
  } catch (err) {
    els.grid.innerHTML = "";
    els.emptyState.hidden = false;
    els.emptyState.textContent =
      "Could not load the collection right now. Please make sure the backend server is running.";
    console.error(err);
  }
}

async function fetchPaintingDetail(id) {
  const res = await fetch(`${API_BASE}/api/paintings/${id}`);
  if (!res.ok) throw new Error("Painting not found");
  return res.json();
}

// ---------------- Search ----------------

let searchDebounce;
function onSearchInput() {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(runSearch, 150);
}

function runSearch() {
  const q = els.searchInput.value.trim().toLowerCase();
  state.filtered = !q
    ? state.all
    : state.all.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.artist.toLowerCase().includes(q) ||
          p.style.toLowerCase().includes(q)
      );
  renderGrid(state.filtered);
}

// ---------------- Rendering ----------------

function renderGrid(list) {
  els.grid.innerHTML = "";
  els.emptyState.hidden = list.length !== 0;

  const count = list.length;
  els.resultsCount.textContent = `${count} painting${count === 1 ? "" : "s"}`;

  const frag = document.createDocumentFragment();
  list.forEach((p, i) => {
    const li = document.createElement("li");
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "painting-card";
    btn.setAttribute(
      "aria-label",
      `${p.title}, by ${p.artist}, ${p.year}. ${p.style}. Open in Listening Room.`
    );
    btn.innerHTML = `
      <span class="card-number">No. ${String(p.id).padStart(3, "0")}</span>
      <span class="card-title">${escapeHtml(p.title)}</span>
      <span class="card-artist">${escapeHtml(p.artist)}</span>
      <span class="card-meta">${escapeHtml(p.year)} · ${escapeHtml(p.style)}</span>
    `;
    btn.addEventListener("click", () => openListeningRoom(list, i));
    li.appendChild(btn);
    frag.appendChild(li);
  });
  els.grid.appendChild(frag);
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---------------- Listening Room ----------------

async function openListeningRoom(list, index) {
  state.filtered = list;
  state.currentIndex = index;
  const summaryItem = list[index];

  stopSpeech();
  els.galleryView.hidden = true;
  els.listeningRoom.hidden = false;
  window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });

  // Show a lightweight placeholder immediately, then fill in full detail
  els.lrTitle.textContent = summaryItem.title;
  els.lrArtist.textContent = summaryItem.artist;
  els.lrYear.textContent = summaryItem.year;
  els.lrStyle.textContent = summaryItem.style;
  els.lrMuseum.textContent = "";
  els.lrColorsText.textContent = "";
  els.lrDescriptionText.textContent = "Loading description…";

  try {
    const full = await fetchPaintingDetail(summaryItem.id);
    state.currentPainting = full;
    els.lrMuseum.textContent = full.museum;
    els.lrColorsText.textContent = full.colors;
    els.lrDescriptionText.textContent = full.description;
    els.backBtn.focus();
    announce(`Opened ${full.title} by ${full.artist} in the Listening Room.`);
  } catch (err) {
    els.lrDescriptionText.textContent =
      "This description could not be loaded. Please go back and try again.";
    console.error(err);
  }
}

function closeListeningRoom() {
  stopSpeech();
  els.listeningRoom.hidden = true;
  els.galleryView.hidden = false;
  els.searchInput.focus();
}

function navigate(delta) {
  if (state.currentIndex < 0) return;
  const next = state.currentIndex + delta;
  if (next < 0 || next >= state.filtered.length) {
    announce(delta > 0 ? "This is the last painting in the list." : "This is the first painting in the list.");
    return;
  }
  openListeningRoom(state.filtered, next);
}

// ---------------- Speech synthesis ----------------

function getSynth() {
  return window.speechSynthesis;
}

function togglePlay() {
  const synth = getSynth();
  if (!synth) {
    announce("Sorry, this browser does not support reading descriptions aloud.");
    return;
  }

  if (synth.speaking && !state.isPaused) {
    synth.pause();
    state.isPaused = true;
    setPlayButtonState(false);
    return;
  }

  if (state.isPaused) {
    synth.resume();
    state.isPaused = false;
    setPlayButtonState(true);
    return;
  }

  startSpeech();
}

function startSpeech() {
  const synth = getSynth();
  if (!synth || !state.currentPainting) return;
  synth.cancel();

  const p = state.currentPainting;
  const text = `${p.title}, by ${p.artist}, ${p.year}. ${p.style}. Palette: ${p.colors}. ${p.description}`;

  const utter = new SpeechSynthesisUtterance(text);
  utter.rate = parseFloat(els.speedRange.value);
  utter.onend = () => {
    state.isPaused = false;
    setPlayButtonState(false);
  };
  utter.onerror = () => {
    state.isPaused = false;
    setPlayButtonState(false);
  };

  state.utterance = utter;
  synth.speak(utter);
  state.isPaused = false;
  setPlayButtonState(true);
}

function stopSpeech() {
  const synth = getSynth();
  if (synth) synth.cancel();
  state.isPaused = false;
  setPlayButtonState(false);
}

function setPlayButtonState(isPlaying) {
  els.playBtn.setAttribute("aria-pressed", String(isPlaying));
  els.playIcon.textContent = isPlaying ? "❚❚" : "▶";
  els.playLabel.textContent = isPlaying ? "Pause description" : "Play description";
}

function onSpeedChange() {
  const rate = parseFloat(els.speedRange.value);
  els.speedValue.textContent = `${rate.toFixed(1)}×`;
  if (state.utterance) {
    // Web Speech API doesn't allow live rate changes on an in-progress
    // utterance in most browsers, so restart at the new rate if playing.
    const synth = getSynth();
    if (synth && synth.speaking && !state.isPaused) {
      startSpeech();
    }
  }
}

function announce(msg) {
  els.liveRegion.textContent = "";
  // Small delay so screen readers reliably pick up repeated messages
  setTimeout(() => { els.liveRegion.textContent = msg; }, 50);
}

// ---------------- Keyboard shortcuts ----------------

function onKeydown(e) {
  const roomOpen = !els.listeningRoom.hidden;
  const inTextInput = e.target === els.searchInput;

  if (!roomOpen || inTextInput) return;

  switch (e.key) {
    case " ":
    case "Spacebar":
      e.preventDefault();
      togglePlay();
      break;
    case "s":
    case "S":
      stopSpeech();
      break;
    case "ArrowRight":
      navigate(1);
      break;
    case "ArrowLeft":
      navigate(-1);
      break;
    case "Escape":
      closeListeningRoom();
      break;
    default:
      break;
  }
}
