# -*- coding: utf-8 -*-
"""
Curated dataset of 100 critically acclaimed paintings.
Each entry includes an accessible "audio description" written to convey
color, composition, mood, and style to a listener who cannot see the image.
"""

PAINTINGS = [
    {
        "id": 1, "title": "The Starry Night", "artist": "Vincent van Gogh", "year": "1889",
        "style": "Post-Impressionism", "museum": "Museum of Modern Art, New York",
        "colors": "Deep cobalt blue, swirling turquoise, bright golden yellow",
        "description": "A small hillside village of dark blue rooftops sleeps beneath a churning night sky. Thick, curling brushstrokes of cobalt and turquoise swirl like currents of wind around eleven glowing yellow stars and a bright crescent moon. On the left a tall, flame-shaped cypress tree rises almost like dark smoke into the sky, its black-green silhouette anchoring the turbulent heavens above the calm little town. The paint is applied in thick, energetic ridges you could almost feel with a fingertip, giving the whole sky a sense of restless motion."
    },
    {
        "id": 2, "title": "Mona Lisa", "artist": "Leonardo da Vinci", "year": "c. 1503-1506",
        "style": "High Renaissance", "museum": "Louvre, Paris",
        "colors": "Warm earthy browns, soft olive greens, muted golds",
        "description": "A woman sits calmly with her hands folded, turned slightly toward the viewer, dressed in a dark, softly draped gown over a plain bodice. Her skin is rendered in warm, smoky tones that fade gently into shadow at the edges of her face, a technique that softens every outline. Behind her a hazy, imaginary landscape of winding paths, a bridge, and blue-grey mountains recedes into misty distance. Her expression is famously ambiguous, the corners of her mouth lifted just enough to suggest a smile that seems to change depending on how long you consider it."
    },
    {
        "id": 3, "title": "The Persistence of Memory", "artist": "Salvador Dalí", "year": "1931",
        "style": "Surrealism", "museum": "Museum of Modern Art, New York",
        "colors": "Burnt orange cliffs, pale blue sky, warm ochre foreground",
        "description": "Three limp pocket watches drape like melting cheese over the edge of a table, a bare tree branch, and a strange fleshy form on the ground. The setting is a barren, dreamlike beach with still golden light and calm blue water in the distance, backed by tall orange cliffs. A fourth watch, closed and covered in ants, lies face down. The mood is eerily quiet and slow, every soft, sagging shape suggesting that time itself has gone loose and unreliable."
    },
    {
        "id": 4, "title": "The Scream", "artist": "Edvard Munch", "year": "1893",
        "style": "Expressionism", "museum": "National Museum, Oslo",
        "colors": "Blazing orange-red sky, deep blue-black fjord, sickly yellow",
        "description": "A gaunt, bald figure stands on a bridge, hands pressed to the sides of an elongated, skull-like face, mouth open in a silent howl. Behind it the sky churns in violent bands of fiery orange and blood red, swirling like flame over a dark blue-black fjord below. Two shadowy companions walk away undisturbed in the distance. Every line in the sky and water curves in sympathy with the figure's scream, as if the whole landscape were vibrating with the same anguish."
    },
    {
        "id": 5, "title": "Girl with a Pearl Earring", "artist": "Johannes Vermeer", "year": "c. 1665",
        "style": "Dutch Golden Age", "museum": "Mauritshuis, The Hague",
        "colors": "Deep black background, warm gold turban with blue band, luminous cream skin",
        "description": "A young woman turns her head over her shoulder to look directly out, lips slightly parted as if caught mid-thought. She wears an exotic gold-and-blue turban wrapped around her head and a single oversized pearl earring that catches a bright point of light. The background is flat, deep black, so all attention falls on her softly lit face and the glowing pearl. The brushwork on her skin is smooth and luminous, almost glazed, in contrast to the looser dabs of paint on the turban's fabric."
    },
    {
        "id": 6, "title": "Guernica", "artist": "Pablo Picasso", "year": "1937",
        "style": "Cubism", "museum": "Museo Reina Sofía, Madrid",
        "colors": "Stark black, white, and grey, no color at all",
        "description": "A large, chaotic mural rendered entirely in black, white, and grey, evoking newsprint and searchlights. Fractured, angular figures of people and animals overlap in panic: a screaming horse pierced by a spear-like shape, a bull standing impassively, a mother wailing as she holds a limp child, a figure falling from a burning building, an arm holding up a flickering lamp. Sharp triangular shapes suggest flames and broken bodies throughout the crowded composition. There is no comforting empty space; every inch of the canvas is packed with anguished, jagged forms depicting the horror of a bombed town."
    },
    {
        "id": 7, "title": "The Night Watch", "artist": "Rembrandt van Rijn", "year": "1642",
        "style": "Dutch Golden Age", "museum": "Rijksmuseum, Amsterdam",
        "colors": "Rich blacks, warm gold and crimson highlights, dramatic chiaroscuro",
        "description": "A civic militia company bursts into motion as if stepping straight out of the frame, led by a captain in black with a red sash and a lieutenant in brilliant gold. Rembrandt uses dramatic contrasts of light and shadow, spotlighting certain faces, a raised musket, and a small girl in a glowing yellow dress carrying a chicken, while other figures recede into deep brown shadow. Flags, spears, and drums crowd the busy scene, giving an impression of noise and bustle rather than a stiff formal group portrait."
    },
    {
        "id": 8, "title": "Water Lilies", "artist": "Claude Monet", "year": "1919",
        "style": "Impressionism", "museum": "Musée de l'Orangerie, Paris",
        "colors": "Soft lavender, mint green, dusky pink, watery blue-green",
        "description": "A pond's surface fills the entire canvas edge to edge, with no horizon, sky, or shoreline in sight. Loose, feathery dabs of lavender, pink, and green paint blur together to suggest floating lily pads and blossoms drifting on rippling water, along with soft reflections of overhanging trees. Up close the brushstrokes look almost abstract, but stepping back they resolve into a tranquil, dreamlike garden pond. The overall effect is soft and hazy, more about the shimmer of light on water than any single sharp detail."
    },
    {
        "id": 9, "title": "American Gothic", "artist": "Grant Wood", "year": "1930",
        "style": "American Regionalism", "museum": "Art Institute of Chicago",
        "colors": "Muted olive green, black, white, and brown farmland tones",
        "description": "A stern-faced farmer in round glasses and dark overalls stands beside a woman in a colonial-print apron, both facing forward with unsmiling, upright posture. He holds a three-pronged pitchfork upright, echoing the pointed Gothic window of the white farmhouse behind them. The palette is restrained and earthy, dominated by olive greens and browns, with crisp white trim on the house standing out sharply. Every line, from the pitchfork to the window to the seam of the man's shirt, is rigid and vertical, giving the whole composition a feeling of plain, unyielding rural severity."
    },
    {
        "id": 10, "title": "The Birth of Venus", "artist": "Sandro Botticelli", "year": "c. 1485",
        "style": "Early Renaissance", "museum": "Uffizi Gallery, Florence",
        "colors": "Pale ivory skin, turquoise sea, soft pink and cream drapery",
        "description": "A nude goddess stands serenely on an enormous open scallop shell that has carried her ashore, one hand modestly covering herself as long, wavy golden hair streams down. To her left, two wind gods embrace mid-air, blowing soft gusts that ripple the pale turquoise sea and scatter pink roses. To her right, a woman in flowing floral robes rushes forward to wrap her in a rose-patterned cloak. The whole scene has a graceful, weightless quality, with elegant curving lines and soft pastel colors rather than deep shadow."
    },
    {
        "id": 11, "title": "Composition VIII", "artist": "Wassily Kandinsky", "year": "1923",
        "style": "Abstract", "museum": "Solomon R. Guggenheim Museum, New York",
        "colors": "Bright primary reds, blues, yellows against cream background",
        "description": "A lively arrangement of geometric shapes floats across a pale cream background: circles of varying sizes in red, blue, and black overlap with triangles, sharp diagonal lines, and a checkerboard patch. There is no recognizable object at all, only shapes interacting like instruments in an orchestra, some large and bold, others small and precise. The overall feeling is one of buoyant, musical energy, as if the shapes are caught mid-movement, bouncing and colliding across the canvas."
    },
    {
        "id": 12, "title": "Las Meninas", "artist": "Diego Velázquez", "year": "1656",
        "style": "Baroque", "museum": "Museo del Prado, Madrid",
        "colors": "Warm browns, muted silvery grey, soft candlelit gold",
        "description": "A young princess stands at the center of a grand, dim palace room, attended by kneeling maids of honor in pale grey gowns. To the left, the painter himself stands at a tall canvas, brush in hand, looking directly outward. A small mirror on the back wall faintly reflects the king and queen, as though they are standing where the viewer stands. Sunlight from an unseen window on the right picks out the princess's golden hair and the maid's dress, while the rest of the room fades into warm brown shadow, creating a hushed, contemplative atmosphere."
    },
    {
        "id": 13, "title": "Nighthawks", "artist": "Edward Hopper", "year": "1942",
        "style": "American Realism", "museum": "Art Institute of Chicago",
        "colors": "Cool green-blue night, warm yellow diner light, deep shadow",
        "description": "Late at night, a brightly lit diner glows on an empty street corner, its curved glass windows wrapping around three customers and a server inside. Two men in hats and a woman in a red dress sit at the counter, spaced apart, none of them speaking to one another. Outside, the street is deserted and rendered in cool, deep blue-green shadow, making the diner's warm yellow interior light feel almost like a stage spotlight. The mood is quiet, isolated, and still, with long, clean architectural lines framing the scene."
    },
    {
        "id": 14, "title": "Impression, Sunrise", "artist": "Claude Monet", "year": "1872",
        "style": "Impressionism", "museum": "Musée Marmottan Monet, Paris",
        "colors": "Soft grey-blue haze, burnt orange sun, muted violet",
        "description": "A hazy harbor at dawn is rendered in loose, quick strokes of grey-blue, with small dark boats barely sketched in silhouette. A single bright orange-red sun hangs low in the misty sky, its reflection breaking into a short, wavy orange streak on the water below. Cranes and masts of distant ships appear only as faint smudges. The whole painting feels soft, quick, and atmospheric, prioritizing the fleeting impression of morning light and mist over any crisp detail, which is exactly what gave the Impressionist movement its name."
    },
    {
        "id": 15, "title": "The Kiss", "artist": "Gustav Klimt", "year": "1908",
        "style": "Art Nouveau / Symbolism", "museum": "Belvedere, Vienna",
        "colors": "Brilliant gold leaf, deep black and cream patterns, rose pink skin",
        "description": "Two figures kneel embraced on a flower-strewn meadow, wrapped together in a shimmering cloak of gold leaf decorated with rectangles and spirals for the man and soft ovals and circles for the woman. He cups her face and leans in to kiss her cheek, and her eyes are closed, her arms wrapped around his neck in tender surrender. Almost the entire background is flat, glowing gold, so the couple seems suspended in a radiant, timeless space, and only the meadow of tiny colorful flowers beneath their knees grounds the scene in the physical world."
    },
    {
        "id": 16, "title": "A Sunday Afternoon on the Island of La Grande Jatte", "artist": "Georges Seurat", "year": "1884-1886",
        "style": "Neo-Impressionism (Pointillism)", "museum": "Art Institute of Chicago",
        "colors": "Cool greens, soft blues, warm orange sunlight dots",
        "description": "A large park scene by a riverbank is built entirely from thousands of tiny, distinct dots of pure color that blend together only when viewed from a distance. Elegantly dressed Parisians stroll, sit, and relax on the grass in the dappled sunlight, including a woman with a monkey on a leash and a girl in a stark white dress that seems to glow. The dots of green, blue, and orange give the whole scene a shimmering, almost vibrating stillness, as though the warm afternoon light itself has been frozen into a fine, granular texture."
    },
    {
        "id": 17, "title": "Whistler's Mother", "artist": "James McNeill Whistler", "year": "1871",
        "style": "Realism", "museum": "Musée d'Orsay, Paris",
        "colors": "Muted greys and blacks, soft white lace accents",
        "description": "An elderly woman in a plain black dress and white lace cap sits in profile, hands folded quietly in her lap, facing left toward a patterned grey curtain. She sits perfectly still in a simple wooden chair, her feet resting on a small footstool, against a flat grey wall hung with a single framed picture. Every tone in the painting is restrained and close in value, mostly soft greys and blacks, creating an overall mood of quiet dignity, patience, and restraint rather than warmth or sentimentality."
    },
    {
        "id": 18, "title": "The Great Wave off Kanagawa", "artist": "Katsushika Hokusai", "year": "c. 1831",
        "style": "Ukiyo-e (Japanese woodblock print)", "museum": "Various collections worldwide",
        "colors": "Deep Prussian blue, white foam, pale grey sky",
        "description": "An enormous cresting wave curls into sharp, claw-like fingers of white foam, towering over three long, low fishing boats caught beneath it. Far in the background, small and calm, sits the snow-capped peak of Mount Fuji, rendered in the same pale colors as the sky so it almost blends into the distance. The wave itself is a deep, rich blue with crisp white spray, drawn with bold, decisive outlines typical of Japanese woodblock printing. The rowers in the boats crouch low, tiny against the wave's overwhelming scale, giving the whole print a sense of thrilling, dangerous motion."
    },
    {
        "id": 19, "title": "Liberty Leading the People", "artist": "Eugène Delacroix", "year": "1830",
        "style": "Romanticism", "museum": "Louvre, Paris",
        "colors": "Smoky greys, French tricolor blue-white-red, warm flesh tones",
        "description": "A bare-chested woman personifying Liberty strides forward over fallen bodies, one arm raising the French tricolor flag high above a crowd of revolutionaries. Around her, an armed boy, a top-hatted bourgeois gentleman, and a wounded soldier surge forward together through drifting battle smoke. The color palette is dominated by smoky grey-browns underfoot, punctuated sharply by the blue, white, and red of the flag streaming above the chaos. The composition pushes the figures forward and slightly upward, giving the whole scene a surging, triumphant momentum despite the grim rubble beneath their feet."
    },
    {
        "id": 20, "title": "Las Señoritas de Avignon", "artist": "Pablo Picasso", "year": "1907",
        "style": "Proto-Cubism", "museum": "Museum of Modern Art, New York",
        "colors": "Warm terracotta pink, stark white, angular blue shadow",
        "description": "Five nude female figures stand and crouch in an angular, fractured space, their bodies broken into sharp geometric planes rather than smooth curves. Two of the faces are painted like African tribal masks, with harsh dark eyes and striped shading, while the others have simplified, mask-like features as well. The background drapery is slashed into jagged triangular folds in blue-white tones, echoing the fractured treatment of the bodies. There is no soft modeling anywhere in the painting; every surface, skin included, is built from flat, angular planes that pushed painting decisively toward abstraction."
    },
    {
        "id": 21, "title": "Christina's World", "artist": "Andrew Wyeth", "year": "1948",
        "style": "American Realism", "museum": "Museum of Modern Art, New York",
        "colors": "Dry golden-brown grass, pale grey sky, muted pink dress",
        "description": "A woman in a pale pink dress lies propped up on one arm in a vast, dry field of golden-brown grass, her body twisted as she gazes up a long hill toward a weathered grey farmhouse in the distance. The field takes up most of the canvas, rendered in countless fine strokes of tan and brown grass blades, emphasizing the sheer distance she must cross. The sky above is flat and pale, offering no drama, which makes the isolation of the small farmhouse and the woman's straining posture feel even more vast and quietly poignant."
    },
    {
        "id": 22, "title": "The Anatomy Lesson of Dr. Nicolaes Tulp", "artist": "Rembrandt van Rijn", "year": "1632",
        "style": "Dutch Golden Age", "museum": "Mauritshuis, The Hague",
        "colors": "Deep black coats, pale cadaver flesh, crisp white ruffs",
        "description": "A group of black-coated physicians in stiff white collars lean in close attention around a pale, exposed cadaver on a table, watching as the lead doctor demonstrates the tendons of the forearm with delicate forceps. Light falls sharply on the cadaver's pale skin and the doctors' attentive faces, while their dark clothing merges into deep shadow. Each man's expression is individually captured, ranging from clinical focus to visible curiosity, giving the group portrait a lively, documentary sense of a real moment happening in front of you."
    },
    {
        "id": 23, "title": "Wanderer above the Sea of Fog", "artist": "Caspar David Friedrich", "year": "1818",
        "style": "Romanticism", "museum": "Kunsthalle Hamburg",
        "colors": "Cool grey-blue mist, dark green-black rock, muted sky",
        "description": "Seen from behind, a lone man in a dark green coat stands atop a craggy rock outcrop, walking stick in hand, gazing out over a vast sea of swirling white-grey fog. Jagged mountain peaks pierce through the mist in the distance, fading into pale, hazy blue as they recede. The man's dark silhouette is the only sharply defined shape in the entire painting, contrasting against the soft, undefined clouds below him. The mood is contemplative and awestruck, a single small figure facing the overwhelming scale of nature."
    },
    {
        "id": 24, "title": "Café Terrace at Night", "artist": "Vincent van Gogh", "year": "1888",
        "style": "Post-Impressionism", "museum": "Kröller-Müller Museum, Netherlands",
        "colors": "Vivid yellow lamplight, deep blue night sky, warm terracotta",
        "description": "A cobblestone street corner glows warmly at night, a café's awning and tables lit by a brilliant yellow gaslamp that spills soft light onto the pavement below. Diners sit at small round tables under the awning, rendered in loose, quick strokes, while the deep blue night sky above is scattered with bright stars, painted directly from life rather than a studio. The contrast between the warm yellow of the café and the cool blue of the sky and shadowed street gives the whole scene a cozy, inviting glow against the vast night."
    },
    {
        "id": 25, "title": "The Garden of Earthly Delights", "artist": "Hieronymus Bosch", "year": "c. 1490-1510",
        "style": "Northern Renaissance", "museum": "Museo del Prado, Madrid",
        "colors": "Lush greens, pale pink flesh, fiery orange and black in the final panel",
        "description": "A vast three-panel painting moves from a peaceful Eden on the left, through an enormous, crowded garden of naked figures, giant fruit, and fantastical creatures in the center, to a nightmarish scene of fire, torture, and monstrous hybrid beings on the right. The central panel is densely packed with small pink figures frolicking among oversized birds, berries, and strange bubble-like structures, all rendered in bright, playful colors. The right-hand panel shifts dramatically to a dark, smoky palette of black and orange, depicting bizarre punishments under a burning night sky, making the whole triptych a journey from paradise to chaos."
    },
    {
        "id": 26, "title": "The Arnolfini Portrait", "artist": "Jan van Eyck", "year": "1434",
        "style": "Northern Renaissance", "museum": "National Gallery, London",
        "colors": "Rich emerald green gown, deep browns, warm red bed hangings",
        "description": "A merchant in a wide black hat and fur-trimmed robe stands holding the hand of a woman in a voluminous emerald green gown, gathered in her free hand as if she were pregnant, inside a richly furnished bedroom. Behind them, a small round mirror on the wall reflects the whole room in miniature, including two additional figures standing in the doorway. A small dog stands at their feet, and a single lit candle burns in the ornate brass chandelier above, even though it is daytime, adding a note of quiet symbolic mystery to the domestic scene."
    },
    {
        "id": 27, "title": "The Third of May 1808", "artist": "Francisco Goya", "year": "1814",
        "style": "Romanticism", "museum": "Museo del Prado, Madrid",
        "colors": "Stark black night, blood red accents, brilliant white shirt",
        "description": "A man in a brilliant white shirt throws his arms wide before a firing squad, his pose echoing a crucifixion, his face lit by a large square lantern on the ground between him and his executioners. The soldiers stand in a faceless, uniform row, their backs to the viewer, rifles raised, while a pile of already-slain bodies lies bloodied in the foreground. The background city fades into near-total blackness, isolating the doomed man's illuminated white shirt and terrified face as the single point of raw emotional focus in the entire canvas."
    },
    {
        "id": 28, "title": "Luncheon of the Boating Party", "artist": "Pierre-Auguste Renoir", "year": "1881",
        "style": "Impressionism", "museum": "The Phillips Collection, Washington D.C.",
        "colors": "Warm sunlit terrace, deep red-orange awning, soft white dresses",
        "description": "A lively group of friends lounges around a table on a riverside terrace, some leaning on the railing, others chatting over wine glasses and fruit, all beneath a striped red-and-white awning. Dappled sunlight filters through, catching on straw hats, a woman's ruffled white dress, and the sparkling water of the river visible in the background. The brushwork is loose and warm throughout, capturing the relaxed, sociable mood of a long afternoon lunch among friends rather than a formal posed gathering."
    },
    {
        "id": 29, "title": "Whistler's Nocturne in Black and Gold", "artist": "James McNeill Whistler", "year": "1875",
        "style": "Tonalism", "museum": "Detroit Institute of Arts",
        "colors": "Deep blue-black night sky, scattered gold sparks",
        "description": "A near-abstract night scene shows a dark park by a river, rendered almost entirely in deep blue-black tones, with tiny bursts of gold and orange scattered across the upper portion of the canvas representing exploding fireworks. A few faint, ghostly silhouettes of figures stand at the bottom edge, barely visible in the gloom. The painting is more about mood, darkness, and the fleeting sparkle of falling embers than any precise detail, offering an atmospheric impression rather than a literal record of the fireworks display."
    },
    {
        "id": 30, "title": "The Sleeping Gypsy", "artist": "Henri Rousseau", "year": "1897",
        "style": "Naïve Art / Primitivism", "museum": "Museum of Modern Art, New York",
        "colors": "Sandy desert tan, striped rainbow robe, moonlit blue",
        "description": "A woman in a long, brightly striped robe of rust, yellow, and blue lies asleep on a moonlit desert sand dune, a walking stick and a mandolin resting beside her. A large lion stands close over her, sniffing at her still body, its mane rendered in careful, almost decorative detail against the flat, pale sand. The full moon glows softly in a deep blue night sky, casting an eerie, dreamlike calm over the whole scene, despite the lion's unsettling closeness."
    },
    {
        "id": 31, "title": "The Hay Wain", "artist": "John Constable", "year": "1821",
        "style": "Romanticism", "museum": "National Gallery, London",
        "colors": "Lush green countryside, soft grey clouds, warm brown cottage",
        "description": "A horse-drawn wooden cart, called a hay wain, stands in a shallow river beside a thatched-roof cottage, its wheels partly submerged in calm, reflective water. Beyond the river, wide green meadows stretch toward distant trees, all under a huge, softly clouded English sky that takes up more than half the canvas. Small, quick touches of white paint highlight the sunlight breaking through the clouds onto the grass, giving the whole rural scene a fresh, breezy, everyday tranquility."
    },
    {
        "id": 32, "title": "Woman with a Parasol", "artist": "Claude Monet", "year": "1875",
        "style": "Impressionism", "museum": "National Gallery of Art, Washington D.C.",
        "colors": "Bright sky blue, crisp white dress, soft green grass",
        "description": "Seen slightly from below against a breezy, cloud-streaked blue sky, a woman in a flowing white dress holds a green-lined parasol tilted to shade her face, her scarf caught mid-flutter in the wind. A small boy stands partly hidden behind her in the tall grass. The brushwork is quick and loose throughout, and the wind seems to move through the entire painting, rippling her dress, the grass, and the clouds all at once, giving a strong sensation of a real gust of air on a bright day."
    },
    {
        "id": 33, "title": "Self-Portrait with Thorn Necklace and Hummingbird", "artist": "Frida Kahlo", "year": "1940",
        "style": "Surrealism / Mexican Folk Art", "museum": "Harry Ransom Center, Austin",
        "colors": "Deep jungle green leaves, black hummingbird, thorny brown necklace",
        "description": "Frida Kahlo stares directly outward with a level, unflinching gaze, her single dark eyebrow forming one continuous line above her eyes. A necklace of thorns digs into her neck, drawing tiny drops of blood, with a limp black hummingbird hanging from its center like a pendant. A black cat crouches on her right shoulder and a small monkey tugs at the thorn necklace on her left, both set against a backdrop of large, flat jungle leaves. Her expression remains calm and steady despite the pain suggested by the thorns, giving the portrait a quiet, defiant strength."
    },
    {
        "id": 34, "title": "Bal du moulin de la Galette", "artist": "Pierre-Auguste Renoir", "year": "1876",
        "style": "Impressionism", "museum": "Musée d'Orsay, Paris",
        "colors": "Dappled golden sunlight, deep blue-black suits, warm pink cheeks",
        "description": "A crowded outdoor dance hall in Paris is filled with couples dancing, chatting, and drinking at tables beneath overhanging trees. Dappled sunlight falls unevenly through the leaves, scattering small patches of gold across dark jackets and straw hats alike, giving the whole scene a flickering, lively texture. Faces throughout the crowd are individually detailed and full of warmth and conversation, painted with soft, blurred edges that suggest the constant movement and noise of a joyful Sunday afternoon party."
    },
    {
        "id": 35, "title": "The Swing", "artist": "Jean-Honoré Fragonard", "year": "1767",
        "style": "Rococo", "museum": "Wallace Collection, London",
        "colors": "Frothy pink dress, lush green foliage, soft golden light",
        "description": "A young woman in a voluminous pink silk dress swings high through a lush, overgrown garden, one of her pink slippers flying off her foot into the air. Below and to the side, a young man hidden in the bushes looks up her skirts as she kicks her leg out playfully, while an older man in the shadows behind pulls the swing's ropes, unaware. Soft, golden dappled light filters through thick green foliage, giving the whole flirtatious scene a warm, playful, faintly mischievous glow."
    },
    {
        "id": 36, "title": "The Death of Marat", "artist": "Jacques-Louis David", "year": "1793",
        "style": "Neoclassicism", "museum": "Royal Museums of Fine Arts of Belgium",
        "colors": "Deep flat black background, pale green-white skin, blood red water",
        "description": "A man lies slumped dead in a bathtub, one arm hanging limply over the side still holding a quill pen, a bloody knife dropped on the floor below him. His skin is pale and greenish, lit by a single unseen light source against a vast, empty, dark background that gives the scene a stark, almost sculptural stillness. A wooden crate beside the tub serves as his writing desk, inscribed simply with a dedication, turning the murder scene into something as calm and composed as a religious martyrdom painting."
    },
    {
        "id": 37, "title": "The Tower of Babel", "artist": "Pieter Bruegel the Elder", "year": "1563",
        "style": "Northern Renaissance", "museum": "Kunsthistorisches Museum, Vienna",
        "colors": "Warm sandy stone, soft grey clouds, muted earth tones",
        "description": "An enormous, unfinished spiral tower of reddish stone rises into low clouds, built in a design similar to the Roman Colosseum but stacked many stories higher, with construction still visibly underway. Tiny figures, cranes, and scaffolding cover every level, so small compared to the tower that they are almost impossible to make out individually. Ships crowd the harbor at its base, and a city sprawls around it, emphasizing through sheer scale how vast and overreaching the ambitious, doomed structure is meant to feel."
    },
    {
        "id": 38, "title": "Whistlejacket", "artist": "George Stubbs", "year": "1762",
        "style": "British Sporting Art", "museum": "National Gallery, London",
        "colors": "Warm chestnut brown coat, plain pale background",
        "description": "A magnificent chestnut-brown horse rears up on its hind legs against a completely bare, pale background, with no rider, saddle, or landscape of any kind to distract from it. Every muscle and gleam of light on its coat is rendered in careful, glossy detail, capturing the animal's power and nervous energy mid-motion. The total absence of any setting makes the horse feel monumental and almost portrait-like, treated with the same seriousness usually reserved for a human sitter."
    },
    {
        "id": 39, "title": "The Umbrellas", "artist": "Pierre-Auguste Renoir", "year": "1886",
        "style": "Impressionism", "museum": "National Gallery, London",
        "colors": "Cool blue-grey umbrellas, muted greens, soft skin tones",
        "description": "A crowd of Parisians huddles beneath a canopy of blue-grey umbrellas on a rainy street, painted in a cooler, more defined style than Renoir's usual warm palette. In the foreground, a little girl without an umbrella stands out clearly, her simple dress a warmer tone against the cool crowd behind her, while a young woman beside her carries a basket. The rounded shapes of the umbrellas overlap rhythmically across the top half of the canvas, creating a repeating pattern that captures the crowded, damp bustle of a city shower."
    },
    {
        "id": 40, "title": "Ophelia", "artist": "John Everett Millais", "year": "1852",
        "style": "Pre-Raphaelite", "museum": "Tate Britain, London",
        "colors": "Rich emerald foliage, pale drowned skin, scattered wildflower colors",
        "description": "A young woman floats on her back in a slow, plant-choked stream, her arms open and her mouth slightly parted as she sings, unaware or unconcerned that she is drowning. Her elaborate embroidered dress billows around her in the water, and loose flowers, poppies, daisies, and violets drift near her on the surface. Every leaf, reed, and petal along the overgrown riverbank is rendered in obsessively fine, jewel-like detail, creating a lush, almost suffocatingly beautiful setting for the quiet tragedy taking place in the water."
    },
    {
        "id": 41, "title": "Nude Descending a Staircase, No. 2", "artist": "Marcel Duchamp", "year": "1912",
        "style": "Cubo-Futurism", "museum": "Philadelphia Museum of Art",
        "colors": "Muted browns and ochres, sepia tones throughout",
        "description": "A single figure descending a staircase is broken into many overlapping, semi-transparent segments, all rendered in warm sepia and brown tones, so that the motion of walking down the stairs is shown as a repeated sequence within one image, similar to a stop-motion photograph. No individual limbs or facial features are distinguishable; instead the eye follows a rhythmic cascade of angular, mechanical-looking shapes moving diagonally down the canvas, translating the sensation of movement through time into a single static image."
    },
    {
        "id": 42, "title": "The Boating Party", "artist": "Mary Cassatt", "year": "1893",
        "style": "Impressionism", "museum": "National Gallery of Art, Washington D.C.",
        "colors": "Bold navy blue, warm yellow-orange, crisp white",
        "description": "A man in a dark navy boater's uniform rows a small boat, his broad back and oar taking up much of the foreground, while a woman in a white dress and a baby in yellow sit facing him in the stern. The composition is unusually flattened and close-up for its time, with the bold curve of the boat's edge cutting sharply across the canvas. Bright, sunlit water fills the background in warm yellow-green tones, and the mother leans forward slightly, drawing an intimate connection between herself, the child, and the rower."
    },
    {
        "id": 43, "title": "The Oxbow", "artist": "Thomas Cole", "year": "1836",
        "style": "Hudson River School", "museum": "Metropolitan Museum of Art, New York",
        "colors": "Stormy dark greens on one side, sunlit gold farmland on the other",
        "description": "The canvas splits dramatically down the middle: on the left, a wild, storm-darkened mountain wilderness of jagged, wind-bent trees sits beneath a churning grey sky, while on the right, a peaceful, sunlit farming valley curves along a horseshoe bend in the river under clear blue sky. A tiny figure of the painter himself, with easel and umbrella, sits on the ridge between the two halves, looking out over the winding river below. The stark contrast between the two sides captures a tension between untamed wilderness and cultivated civilization."
    },
    {
        "id": 44, "title": "Christ of Saint John of the Cross", "artist": "Salvador Dalí", "year": "1951",
        "style": "Surrealism", "museum": "Kelvingrove Art Gallery, Glasgow",
        "colors": "Deep black sky, warm golden light on the figure, cool blue-green water below",
        "description": "Christ on the cross is seen from a dramatic bird's-eye angle, floating above a dark, star-flecked sky with no visible nails, blood, or crown of thorns. Far below, tiny fishermen stand calmly beside boats on a glassy, moonlit shore, giving an enormous sense of scale and distance between the divine figure above and the ordinary world below. The cross itself is lit with a soft, warm golden glow that stands out sharply against the deep, cool darkness surrounding it, creating a serene, almost weightless sense of transcendence rather than suffering."
    },
    {
        "id": 45, "title": "The Lady of Shalott", "artist": "John William Waterhouse", "year": "1888",
        "style": "Pre-Raphaelite", "museum": "Tate Britain, London",
        "colors": "Deep autumnal browns, pale skin, rich embroidered tapestry colors",
        "description": "A woman in a flowing white gown sits in a small wooden boat drifting through reeds on a dark, still river at dusk, three candles beside her, only one still lit. An elaborately embroidered tapestry, showing scenes she wove while imprisoned in her tower, trails over the side of the boat into the water. Her expression is sorrowful and resigned, her hands loosely holding the boat's chain as autumn leaves scatter around her. The muted, twilight colors and drifting composition give the whole scene a slow, melancholic, fatal calm."
    },
    {
        "id": 46, "title": "Autumn Rhythm (Number 30)", "artist": "Jackson Pollock", "year": "1950",
        "style": "Abstract Expressionism", "museum": "Metropolitan Museum of Art, New York",
        "colors": "Black, white, and brown tangled lines on raw canvas",
        "description": "A vast, unstretched canvas is covered edge to edge with looping, dripped, and flung lines of black, white, and brown paint, layered over one another with no single focal point or recognizable shape. The lines vary from thick pours to fine, thread-like spatters, creating a dense, all-over web of energetic motion across the entire surface. There is no top, bottom, or center to focus on; instead the eye is meant to wander continuously across the tangled rhythm of the painter's physical movements while making it."
    },
    {
        "id": 47, "title": "Dance at Le Moulin de la Galette", "artist": "Edgar Degas", "year": "1876",
        "style": "Impressionism", "museum": "Musée d'Orsay, Paris",
        "colors": "Warm stage lighting, soft pastel tutus, dark orchestra pit",
        "description": "Ballet dancers in pale pink and white tutus rehearse on stage, caught in casual, unposed positions, stretching, adjusting a shoulder strap, or waiting their turn, rather than performing a formal, symmetrical routine. The composition is cropped unusually close and at an angle, as if glimpsed candidly from the wings or the orchestra pit, with instrument necks visible at the very bottom edge. Warm stage light falls unevenly across the dancers, leaving some in soft shadow, capturing the informal, behind-the-scenes atmosphere of a working rehearsal rather than a grand performance."
    },
    {
        "id": 48, "title": "Judith Slaying Holofernes", "artist": "Artemisia Gentileschi", "year": "1614-1620",
        "style": "Baroque", "museum": "Uffizi Gallery, Florence",
        "colors": "Deep red blood, warm gold bedding, dramatic dark shadow",
        "description": "Two women pin down a struggling man on a bed, one gripping his hair and pressing a sword firmly across his throat while blood sprays vividly across the white sheets. Their expressions are focused and physically strained, arms tensed with real effort rather than delicate grace, set dramatically against a plain, deep shadowed background that throws all the light onto the violent struggle. The composition is close, tight, and unflinching, treating the biblical scene with visceral physical realism rather than restrained, distant decorum."
    },
    {
        "id": 49, "title": "The Ambassadors", "artist": "Hans Holbein the Younger", "year": "1533",
        "style": "Northern Renaissance", "museum": "National Gallery, London",
        "colors": "Rich green curtain, deep black and gold fur-trimmed robes",
        "description": "Two well-dressed men stand on either side of a two-tiered table crowded with globes, musical instruments, books, and scientific tools, symbols of their worldly knowledge and status. A rich green curtain hangs behind them, and both men wear luxurious fur-trimmed robes in black, gold, and pink. At the very bottom of the painting, a strange, elongated grey smear stretches diagonally across the floor; viewed from a sharp angle to the side, it resolves into a human skull, a hidden reminder of death lurking beneath the men's worldly achievements."
    },
    {
        "id": 50, "title": "The Fighting Temeraire", "artist": "J.M.W. Turner", "year": "1839",
        "style": "Romanticism", "museum": "National Gallery, London",
        "colors": "Fiery orange-gold sunset, pale ghostly ship, cool blue water",
        "description": "A ghostly pale, tall-masted warship is towed slowly by a small, dark, smoke-belching steam tugboat across calm water toward its final destination to be broken apart for scrap. Behind them, an enormous, blazing sunset fills nearly half the sky with molten orange, gold, and pink clouds reflected in the still water below. The contrast between the old sailing ship's pale, fading elegance and the tugboat's harsh black smoke captures the passing of an era, wrapped in one of the most spectacular skies in all of British painting."
    },
    {
        "id": 51, "title": "The Blue Boy", "artist": "Thomas Gainsborough", "year": "c. 1770",
        "style": "British Portraiture", "museum": "The Huntington, California",
        "colors": "Shimmering blue-grey satin, warm brown landscape background",
        "description": "A young boy stands confidently in an elaborate satin costume of shimmering blue and silver-grey, one hand resting on his hip, the other holding a plumed hat at his side. The fabric of his suit is painted with loose, fluid brushstrokes that catch the light in cool silvery highlights against darker blue shadow. Behind him, a soft, warm brown landscape with a hint of stormy sky recedes into the distance, its earthy tones making the boy's cool blue costume stand out even more vividly in the foreground."
    },
    {
        "id": 52, "title": "The School of Athens", "artist": "Raphael", "year": "1509-1511",
        "style": "High Renaissance", "museum": "Vatican Museums",
        "colors": "Warm marble tones, sky blue robes, soft ochre stone",
        "description": "Dozens of ancient philosophers and scholars gather beneath towering marble arches, engaged in discussion, reading, and demonstration, arranged in loose clusters across a grand architectural hall that recedes dramatically into the distance. At the center, two central figures walk forward together, one pointing up toward the sky, the other gesturing flat toward the earth, symbolizing different paths to truth. The architecture itself, with its rounded arches and coffered ceiling, is rendered with mathematically precise perspective, giving the whole enormous gathering a sense of orderly, harmonious grandeur."
    },
    {
        "id": 53, "title": "Olympia", "artist": "Édouard Manet", "year": "1863",
        "style": "Realism", "museum": "Musée d'Orsay, Paris",
        "colors": "Pale flesh tones, stark white sheets, deep black background accents",
        "description": "A nude woman reclines on white pillows and sheets, one hand resting firmly on her thigh, staring directly and unapologetically out at the viewer rather than looking away demurely. A black cat with an arched back stands alert at the foot of the bed, and a Black servant woman presents her with a large bouquet of flowers. The flattened lighting removes most soft shadow, giving her skin a stark, almost harsh brightness against the dark background, and her confident, level gaze was considered shockingly frank for its time."
    },
    {
        "id": 54, "title": "The Raft of the Medusa", "artist": "Théodore Géricault", "year": "1818-1819",
        "style": "Romanticism", "museum": "Louvre, Paris",
        "colors": "Stormy grey-green sea, pale exhausted bodies, distant warm hope of a sail",
        "description": "A crowd of desperate, emaciated shipwreck survivors clings to a makeshift wooden raft on a violent, grey-green sea, their bodies piled in a diagonal pyramid rising toward one man waving a cloth at a tiny, barely visible ship on the horizon. Some figures in the foreground are already dead or dying, their pale skin rendered with unflinching, almost clinical realism. The turbulent water and dark, stormy sky press in from every side, while the small triangle of hopeful, straining bodies at the peak of the raft strains upward against the overwhelming scale of the sea around them."
    },
    {
        "id": 55, "title": "Las Dos Fridas (The Two Fridas)", "artist": "Frida Kahlo", "year": "1939",
        "style": "Surrealism / Mexican Folk Art", "museum": "Museo de Arte Moderno, Mexico City",
        "colors": "Stark white Victorian dress, vivid Tehuana orange and yellow, deep red blood",
        "description": "Two versions of the same woman sit side by side holding hands beneath a stormy grey sky, their hearts exposed and connected by a single visible red artery looping between them. One Frida wears a white European lace wedding dress stained with blood where she pinches the artery closed with forceps; the other wears a vivid orange and yellow traditional Tehuana dress, her heart whole. The exposed anatomical hearts are rendered in vivid, glistening red against the pale and colorful fabrics, visually connecting the two identities as one shared, wounded self."
    },
    {
        "id": 56, "title": "The Two Fridas", "artist": "Diego Rivera (Mural Detail Style)", "year": "1930s",
        "style": "Mexican Muralism", "museum": "Palacio Nacional, Mexico City",
        "colors": "Warm terracotta, deep indigenous reds, earthy browns",
        "description": "A sweeping mural-style scene depicts layered chapters of history, with crowds of laborers, indigenous figures, and industrial machinery packed across a wide horizontal composition. Warm terracotta and earthy red tones dominate the crowd scenes, while cooler greys and blacks mark the industrial and mechanical sections. Figures are rendered with simplified, sturdy, monumental forms rather than fine detail, emphasizing collective labor and historical struggle over any single individual, in the bold, didactic style typical of large Mexican mural painting."
    },
    {
        "id": 57, "title": "Nude, Green Leaves and Bust", "artist": "Pablo Picasso", "year": "1932",
        "style": "Cubism / Surrealism", "museum": "Private collection",
        "colors": "Soft lavender-violet skin, deep green leaves, warm yellow background",
        "description": "A reclining nude woman is rendered in soft, rounded, biomorphic curves in gentle lavender and violet tones, her body simplified into smooth, overlapping shapes rather than realistic anatomy. Large green leaf forms curl around her figure, echoing the curve of her arms and hair, set against a warm, flat yellow background. A small sculpted bust appears faintly layered into the composition near her head. The overall mood is soft, sensuous, and dreamlike, using color and curved shape rather than sharp lines to convey a restful, private mood."
    },
    {
        "id": 58, "title": "The Storm on the Sea of Galilee", "artist": "Rembrandt van Rijn", "year": "1633",
        "style": "Baroque", "museum": "Formerly Isabella Stewart Gardner Museum (stolen 1990)",
        "colors": "Dark stormy green-grey waves, warm lantern glow on deck",
        "description": "A small fishing boat pitches violently on dark, foaming waves during a sudden storm, its sail torn and passengers scrambling in fear, one leaning over the side seasick, others hauling desperately on ropes. A warm, small pool of lantern light illuminates a cluster of frightened faces near the mast, including a calm, steady figure believed to wake and still the storm. The choppy, churning water and heavy, dark storm clouds surround the tiny boat on all sides, emphasizing its fragility against the overwhelming power of the sea."
    },
    {
        "id": 59, "title": "Bacchus and Ariadne", "artist": "Titian", "year": "1520-1523",
        "style": "High Renaissance / Venetian School", "museum": "National Gallery, London",
        "colors": "Vivid ultramarine sky, rich crimson cloak, warm golden skin",
        "description": "A young god leaps dramatically from his leopard-drawn chariot toward a startled woman standing on a shoreline, his crimson cloak billowing dramatically behind him in mid-air. Behind him, a rowdy procession of satyrs and revelers, one wrapped in writhing snakes, tumbles across the canvas in a chaotic, joyful crowd. The sky above is an intense, saturated blue, among the most celebrated uses of that pigment in Renaissance painting, contrasting vividly with the warm golden flesh tones and rich reds of the figures below."
    },
    {
        "id": 60, "title": "Las Meninas-inspired Portrait: Infanta Margarita", "artist": "Diego Velázquez (Studio)", "year": "1660",
        "style": "Baroque", "museum": "Kunsthistorisches Museum, Vienna",
        "colors": "Silvery blue-grey gown, pale skin, soft brown background",
        "description": "A young princess stands stiffly formal in an enormous, structured silver-blue gown, its wide skirt nearly as broad as she is tall, trimmed with delicate silver lace. Her hair is elaborately styled with ribbons on either side of her small, serious face. The background is a plain, warm brown, keeping full attention on the shimmering, carefully rendered texture of the heavy silk gown, painted with loose, confident brushstrokes that up close look almost abstract but resolve into rich fabric from a normal viewing distance."
    },
    {
        "id": 61, "title": "The Card Players", "artist": "Paul Cézanne", "year": "1892-1893",
        "style": "Post-Impressionism", "museum": "Musée d'Orsay, Paris (one version)",
        "colors": "Muted earthy browns, soft blues, warm ochre",
        "description": "Two men sit facing each other at a plain wooden table, entirely absorbed in a card game, their postures mirrored in quiet concentration with a wine bottle standing between them. The colors throughout are muted and earthy, browns, ochres, and soft blues, applied in solid, faceted patches that give the men's clothing and the table a sturdy, almost sculptural weight. There is no dramatic action or expression, just calm, patient stillness, built from simplified, geometric blocks of steady color rather than fine realistic detail."
    },
    {
        "id": 62, "title": "The Absinthe Drinker", "artist": "Edgar Degas", "year": "1875-1876",
        "style": "Impressionism / Realism", "museum": "Musée d'Orsay, Paris",
        "colors": "Muted greys and browns, pale green absinthe glass",
        "description": "A woman sits slumped at a café table, staring blankly ahead, a pale green-yellow glass of absinthe in front of her, while a man beside her looks off in another direction, smoking a pipe. The composition is unusually off-center, with a large empty expanse of table taking up much of the foreground, emphasizing the emotional distance and isolation between the two figures. The colors are subdued greys and browns throughout, giving the entire scene a flat, weary, melancholic mood typical of modern city life."
    },
    {
        "id": 63, "title": "Paris Street; Rainy Day", "artist": "Gustave Caillebotte", "year": "1877",
        "style": "Impressionism / Realism", "museum": "Art Institute of Chicago",
        "colors": "Cool grey cobblestones, muted blue-black umbrellas, soft silver sky",
        "description": "A wide Parisian intersection stretches out under a damp grey sky, its cobblestones glistening with rain, as well-dressed pedestrians holding dark umbrellas cross in different directions. A couple in the foreground, sharply detailed and close to the viewer, walks arm in arm beneath a shared umbrella, while other figures grow softer and hazier in the distance. The buildings' sharp architectural lines and the precise, almost photographic perspective give the scene an unusually crisp, structured feel compared to looser, more typical Impressionist works."
    },
    {
        "id": 64, "title": "Wheatfield with Crows", "artist": "Vincent van Gogh", "year": "1890",
        "style": "Post-Impressionism", "museum": "Van Gogh Museum, Amsterdam",
        "colors": "Deep stormy blue sky, golden wheat, black crows",
        "description": "A turbulent, dark blue sky presses down over a wide field of thick, golden wheat, painted in urgent, heavy strokes that seem to bend and sway as if in strong wind. A flock of black crows scatters up and away from the field, their sharp wing shapes cutting across the sky in different directions. Three rough dirt paths cut through the wheat, one leading straight toward the viewer and two curving off to either side without a clear destination, giving the whole composition a restless, unresolved tension."
    },
    {
        "id": 65, "title": "Portrait of Adele Bloch-Bauer I", "artist": "Gustav Klimt", "year": "1907",
        "style": "Art Nouveau / Symbolism", "museum": "Neue Galerie, New York",
        "colors": "Radiant gold leaf, deep black hair, warm skin",
        "description": "A woman sits with her hands clasped, almost entirely enveloped in an intricate field of gold leaf decorated with swirling eye-like ovals, triangles, and geometric patterns that blur the line between her body, her dress, and the background itself. Only her pale face, neck, and hands emerge clearly from the dazzling gold, her dark hair piled elegantly atop her head. The overall effect is opulent and shimmering, more like a bejeweled icon than a conventional portrait, with barely any distinction between figure and setting."
    },
    {
        "id": 66, "title": "Christina's Wagon: American Gothic style companion, Fall Plowing", "artist": "Grant Wood", "year": "1931",
        "style": "American Regionalism", "museum": "Art Institute of Chicago",
        "colors": "Rolling green and brown fields, pale sky",
        "description": "A single plow sits abandoned in a foreground field, its curved rows of freshly turned dark brown earth contrasting against smooth, rounded green hills that roll gently into the distance like folded fabric. Tiny farm buildings and trees dot the simplified, stylized landscape, everything rendered with smooth, exaggerated curves rather than realistic texture. The pale, calm sky above takes up a modest band at the top, keeping the focus on the rhythmic, almost sculpted patterns of the cultivated land below."
    },
    {
        "id": 67, "title": "The Disasters of War: This Is Worse, plate 37", "artist": "Francisco Goya", "year": "1810-1820",
        "style": "Romanticism / Printmaking", "museum": "Various print collections",
        "colors": "Stark black and white etching, no color",
        "description": "A brutal etched scene rendered only in black ink and white paper shows the harsh aftermath of war, dead and mutilated bodies depicted with unflinching, documentary directness rather than heroic idealization. The linework is scratchy, urgent, and dense in the shadowed areas, thinning to bare white paper where light would fall. There is no color to soften the image, only stark contrast, giving the print a raw, immediate, journalistic honesty about the brutality of conflict."
    },
    {
        "id": 68, "title": "The Kiss (sculpture-inspired painting)", "artist": "Constantin Brâncuși style — Rodin's The Kiss theme in paint", "year": "c. 1900s",
        "style": "Symbolism", "museum": "Various",
        "colors": "Soft warm marble tones, muted background",
        "description": "Two embracing figures lean into one another, rendered with smooth, simplified contours in warm, muted flesh tones against a soft, indistinct background. Their forms curve together in a single unified silhouette, arms wrapped closely, heads tilted toward each other in an intimate, tender pose. The lack of sharp background detail keeps full attention on the gentle curves and quiet closeness of the two figures, conveying warmth and tenderness through simplified, rounded shape rather than fine detail."
    },
    {
        "id": 69, "title": "The Milkmaid", "artist": "Johannes Vermeer", "year": "c. 1658-1661",
        "style": "Dutch Golden Age", "museum": "Rijksmuseum, Amsterdam",
        "colors": "Deep ultramarine blue apron, warm mustard yellow bodice, soft white wall",
        "description": "A sturdy young woman stands at a plain kitchen table, pouring milk slowly and steadily from a jug into a bowl, her sleeves rolled up for work. She wears a warm mustard-yellow bodice and a deep, rich blue apron, colors that stand out vividly against the plain whitewashed wall behind her. Soft daylight falls from a window on the left, catching individual droplets of milk in mid-pour and small dents and chips in the humble earthenware on the table, giving the everyday scene a quiet, dignified glow."
    },
    {
        "id": 70, "title": "View of Toledo", "artist": "El Greco", "year": "c. 1596-1600",
        "style": "Mannerism", "museum": "Metropolitan Museum of Art, New York",
        "colors": "Stormy blue-green sky, dark hillside, pale grey city buildings",
        "description": "A hilltop city of pale grey stone buildings and a fortress sits beneath a wild, dramatically lit stormy sky of deep blue-green and grey clouds. The landscape below is rendered in unusually elongated, twisting shapes, with dark, almost black-green hills and trees pressing close to the city walls. Streaks of eerie, cool light break through the clouds in places, giving the whole scene a tense, supernatural atmosphere rather than a calm, documentary view of the city."
    },
    {
        "id": 71, "title": "The Night Café", "artist": "Vincent van Gogh", "year": "1888",
        "style": "Post-Impressionism", "museum": "Yale University Art Gallery",
        "colors": "Clashing acid green ceiling, blood red walls, harsh yellow lamps",
        "description": "A garish billiard hall interior glows under harsh yellow gaslamps hanging from a sickly green ceiling, its walls painted a deep, aggressive blood red. A green billiard table sits empty at the center of the room, while a few slouched, isolated figures sit at tables along the walls or stand near the bar. Van Gogh intentionally clashed the reds and greens throughout the room, later writing that he wanted the colors themselves to express a place where a person could ruin themselves, giving the whole scene an unsettling, feverish intensity."
    },
    {
        "id": 72, "title": "Portrait of Dr. Gachet", "artist": "Vincent van Gogh", "year": "1890",
        "style": "Post-Impressionism", "museum": "Private collection",
        "colors": "Cool blue coat and background, warm pink skin",
        "description": "A man rests his head on his hand, elbow propped on a red table, his expression weary and melancholic beneath a pale blue cap that matches his blue coat and the swirling blue-toned background behind him. Two small yellow books and a stem of purple foxglove sit on the table in front of him. The cool blues surrounding his face contrast with his warm pink skin tones, and the loose, wavy brushstrokes throughout the background seem to echo his tired, unsettled state of mind."
    },
    {
        "id": 73, "title": "The Ninth Wave", "artist": "Ivan Aivazovsky", "year": "1850",
        "style": "Romanticism / Marine painting", "museum": "State Russian Museum, St. Petersburg",
        "colors": "Glowing golden-orange dawn light, deep turquoise waves",
        "description": "Survivors of a shipwreck cling to a floating mast in enormous, translucent turquoise waves lit from behind by a glowing golden sunrise breaking through storm clouds. The light gives the towering waves an almost fiery, glass-like transparency, with foam catching bright orange and pink highlights along their crests. Despite the danger of the churning sea, the warm dawn light suggests the storm is passing, giving the whole dramatic scene a fragile, hopeful undertone."
    },
    {
        "id": 74, "title": "The Old Guitarist", "artist": "Pablo Picasso", "year": "1903-1904",
        "style": "Blue Period", "museum": "Art Institute of Chicago",
        "colors": "Deep monochrome blues throughout",
        "description": "An elderly, gaunt man sits hunched on the ground, his body folded awkwardly around a large guitar, painted almost entirely in somber, muted shades of blue with only faint touches of brown. His closed eyes and bowed head suggest blindness or deep exhaustion, his long fingers curled carefully over the guitar's strings. The near-total absence of any other color gives the painting a cold, mournful, almost ghostly stillness, emphasizing poverty and quiet endurance through tone alone rather than detail or setting."
    },
    {
        "id": 75, "title": "Le Déjeuner sur l'herbe", "artist": "Édouard Manet", "year": "1863",
        "style": "Realism", "museum": "Musée d'Orsay, Paris",
        "colors": "Deep forest greens, stark pale nude skin, dark formal suits",
        "description": "A nude woman sits casually on the grass in a wooded picnic clearing between two fully dressed men in dark suits, all three seemingly mid-conversation, while a second woman bathes in a stream in the background. The nude woman looks directly and calmly out at the viewer, her frank gaze considered startling next to the men's formal daywear. Rich, deep greens of the forest surround the group, and the flattened, sketch-like brushwork throughout gives the traditional picnic scene an unusually blunt, modern, unidealized realism."
    },
    {
        "id": 76, "title": "The Weeping Woman", "artist": "Pablo Picasso", "year": "1937",
        "style": "Cubism", "museum": "Tate Modern, London",
        "colors": "Harsh yellow, sharp blue-green, jagged black lines",
        "description": "A woman's face is fractured into sharp, angular planes of harsh yellow, green, and blue, her features rearranged so that both eyes, her nose, and her handkerchief-clutching hand all crowd toward the same jagged, tear-streaked area of her face. Thick black outlines cut through every shape like broken glass, and her mouth is pulled into a distorted, anguished grimace. The clashing, unnatural colors and fractured geometry combine to convey raw, overwhelming grief more intensely than a realistic portrait could."
    },
    {
        "id": 77, "title": "The Third Class Carriage", "artist": "Honoré Daumier", "year": "c. 1862-1864",
        "style": "Realism", "museum": "Metropolitan Museum of Art, New York",
        "colors": "Muted browns and greys, soft warm skin tones",
        "description": "A crowded, plain wooden train carriage holds ordinary working-class passengers, an elderly woman with a sleeping baby, a young boy asleep against his grandmother, and rows of tired, anonymous travelers behind them. The palette is subdued and earthy, browns and greys, with soft light picking out only the faces and hands of the front row clearly, while the crowd behind fades into loose, sketchy shadow. The mood is quietly weary and dignified, focused on the endurance of ordinary people rather than any dramatic event."
    },
    {
        "id": 78, "title": "Christina's Field: Wheatfield with Cypresses", "artist": "Vincent van Gogh", "year": "1889",
        "style": "Post-Impressionism", "museum": "Metropolitan Museum of Art, New York",
        "colors": "Golden wheat, deep green cypress, swirling blue sky",
        "description": "A tall, dark green cypress tree twists upward on the right side of a golden wheat field, its flame-like shape echoed by swirling, wind-blown clouds in the bright blue sky above. The wheat below ripples in short, energetic strokes of gold and green, suggesting a strong, constant breeze moving across the whole landscape. Every element, tree, cloud, and wheat, seems to share the same restless, curling rhythm, unifying the entire sunny scene through motion rather than stillness."
    },
    {
        "id": 79, "title": "Christ in the House of His Parents", "artist": "John Everett Millais", "year": "1849-1850",
        "style": "Pre-Raphaelite", "museum": "Tate Britain, London",
        "colors": "Warm wood-shop browns, soft blue and red robes",
        "description": "Inside a humble, cluttered carpenter's workshop, a young boy has cut his hand on a nail, a small drop of blood on his palm foreshadowing later wounds, while his family gathers around him with concern. Every wood shaving, tool, and plank in the workshop is rendered with painstaking, almost obsessive realistic detail, avoiding any idealized softness typically given to religious scenes. The warm browns of the wood and simple work clothes ground the holy family firmly in ordinary, everyday physical labor rather than distant, golden-lit sanctity."
    },
    {
        "id": 80, "title": "The Music Lesson", "artist": "Johannes Vermeer", "year": "c. 1662-1665",
        "style": "Dutch Golden Age", "museum": "Royal Collection, London",
        "colors": "Cool black and white checkerboard floor, warm golden light",
        "description": "A young woman stands at a keyboard instrument in a sunlit room, her back mostly turned, while a man stands close beside her, seemingly guiding her playing, both reflected faintly in a mirror above the instrument. The floor is a crisp black and white checkerboard pattern receding in careful perspective, and warm daylight from a leaded window catches the folds of the woman's dress and the instrument's lid. The quiet, orderly room and the intimate but formal distance between the two figures give the scene a restrained, contemplative calm."
    },
    {
        "id": 81, "title": "Bedroom in Arles", "artist": "Vincent van Gogh", "year": "1888",
        "style": "Post-Impressionism", "museum": "Van Gogh Museum, Amsterdam",
        "colors": "Vivid blue walls, warm yellow bed frame, deep red floor tiles",
        "description": "A simple bedroom is rendered in flat, bold blocks of color: sky blue walls, a bright yellow wooden bed and chairs, and a deep reddish-brown floor, all outlined in dark, confident strokes. The perspective is slightly tilted and uneven, giving the small, tidy room a warm, tipsy, dreamlike quality rather than strict architectural accuracy. Small paintings hang crookedly on the walls, and the overall mood, achieved entirely through bold, contrasting color blocks rather than realistic shading, is one of restful, simple domestic calm."
    },
    {
        "id": 82, "title": "The Gleaners", "artist": "Jean-François Millet", "year": "1857",
        "style": "Realism", "museum": "Musée d'Orsay, Paris",
        "colors": "Warm golden harvest field, muted earthy peasant clothing",
        "description": "Three peasant women bend low across a vast, golden harvested field, gathering the last leftover stalks of wheat after the main harvest, their simple clothing in muted blues, reds, and browns. Their broad, sturdy bodies and bent postures are rendered with quiet monumental dignity, taking up the foreground against a wide, sunlit field that stretches to a distant harvest scene with wagons and haystacks. The warm, golden light across the whole field lends humble, repetitive manual labor a solemn, almost sacred weight."
    },
    {
        "id": 83, "title": "A Bar at the Folies-Bergère", "artist": "Édouard Manet", "year": "1882",
        "style": "Realism / Impressionism", "museum": "Courtauld Gallery, London",
        "colors": "Sparkling gold champagne bottles, cool marble bar, warm skin tones",
        "description": "A young barmaid stands behind a marble counter crowded with bottles of champagne, wine, and a bowl of oranges, her expression distant and slightly melancholic despite the lively, blurred crowd reflected in the mirror behind her. The mirror reveals a bright chandelier-lit theater full of tiny figures, and, oddly, a reflection of the barmaid herself from behind, talking to a top-hatted customer who should be standing where the viewer stands. The sparkling glass bottles and rich colors of the crowd sit in gentle tension with the barmaid's quiet, weary stillness in the foreground."
    },
    {
        "id": 84, "title": "Dante and Virgil in Hell", "artist": "William-Adolphe Bouguereau", "year": "1850",
        "style": "Academic Art", "museum": "Musée d'Orsay, Paris",
        "colors": "Fiery orange-red background, pale straining flesh",
        "description": "Two nude men grapple violently in the foreground, one biting fiercely into the other's neck, their muscles straining with dramatic, sculptural precision against a hazy, fiery orange-red backdrop of hell. Onlooking demons and shadowy damned figures crowd the background, watching the brutal fight with detached curiosity. Every muscle, vein, and strained tendon of the wrestling bodies is rendered with intense anatomical realism, contrasted against the smoky, hellish glow behind them, giving the violent scene a heightened, theatrical intensity."
    },
    {
        "id": 85, "title": "Portrait of Madame X", "artist": "John Singer Sargent", "year": "1884",
        "style": "Realism / Aestheticism", "museum": "Metropolitan Museum of Art, New York",
        "colors": "Stark black velvet gown, pale lavender-white skin",
        "description": "A woman stands in profile in a striking black velvet evening gown with a single jeweled strap, her pale, almost lavender-white skin standing out sharply against the deep black fabric and dark background. Her chin is lifted with cool, confident poise, one arm turned to rest on a small table. The dramatic contrast between her powdered pale skin and the gown's rich blackness, combined with her aloof profile pose, gives the portrait an elegant, faintly scandalous air of sophisticated self-possession."
    },
    {
        "id": 86, "title": "The Hay Harvest", "artist": "Pieter Bruegel the Elder", "year": "1565",
        "style": "Northern Renaissance", "museum": "Lobkowicz Palace, Prague",
        "colors": "Warm golden fields, soft blue-green distant hills",
        "description": "Peasant workers cut, rake, and carry bundles of hay across a wide, sweeping golden landscape that recedes into soft, hazy blue-green hills far in the distance. Small figures are scattered throughout the busy scene, some resting to eat under a tree in the foreground, others still bent over their work farther back. The high vantage point looks down over the whole valley at once, giving a broad, panoramic sense of a full agricultural community working together through the warm, golden days of summer harvest."
    },
    {
        "id": 87, "title": "Vase with Twelve Sunflowers", "artist": "Vincent van Gogh", "year": "1888",
        "style": "Post-Impressionism", "museum": "Neue Pinakothek, Munich",
        "colors": "Vivid golds, warm ochres, bright yellow background",
        "description": "A simple ceramic vase holds a bold, sprawling bunch of sunflowers at every stage of life, some fully bloomed and bright yellow, others browning and drooping with heavy, drying seed heads. Thick, energetic brushstrokes build up the petals and leaves in slightly varying shades of yellow and gold, set against a matching bright yellow background that makes the whole canvas glow with warmth. The nearly monochromatic yellow palette, varied only through texture and thick paint, gives the humble flowers an almost radiant, sun-like intensity."
    },
    {
        "id": 88, "title": "The Assumption of the Virgin", "artist": "Titian", "year": "1516-1518",
        "style": "High Renaissance / Venetian School", "museum": "Basilica di Santa Maria Gloriosa dei Frari, Venice",
        "colors": "Rich crimson robes, warm golden light, deep blue sky",
        "description": "The Virgin Mary rises upward through a golden, glowing cloud of small cherub faces, her red robe and blue mantle billowing dramatically as she ascends toward God the Father waiting above. Below her, the twelve apostles crowd together on the ground, their arms thrown up in astonishment and awe as they watch her rise. The composition is built in three clear tiers, earth, ascension, and heaven, with warm reds and golds growing brighter and more radiant toward the top of the enormous altarpiece."
    },
    {
        "id": 89, "title": "The Last Supper", "artist": "Leonardo da Vinci", "year": "1495-1498",
        "style": "High Renaissance", "museum": "Santa Maria delle Grazie, Milan",
        "colors": "Warm earthy tones, soft blue and red robes, muted architecture",
        "description": "Thirteen men sit along one side of a long table inside a simply decorated room, grouped in clusters of three, each reacting with a different gesture of shock, denial, or concern after hearing that one of them will betray their leader. The central figure sits calmly with arms spread in quiet acceptance, framed perfectly by a window and doorway behind him that draw the eye directly to his face. The whole room's architecture uses precise linear perspective converging exactly on that central figure, unifying the emotional chaos of the other twelve around his still, composed center."
    },
    {
        "id": 90, "title": "The Creation of Adam", "artist": "Michelangelo", "year": "1508-1512",
        "style": "High Renaissance", "museum": "Sistine Chapel, Vatican City",
        "colors": "Warm flesh tones, soft muted sky and cloud grey-blue",
        "description": "A muscular, reclining nude man lies on a rocky green hillside, one arm stretched languidly toward an elderly, bearded figure in flowing robes who reaches back toward him from within a swirling cloud filled with other figures and a young woman. The two extended index fingers almost, but do not quite, touch, leaving a small, famous gap of empty space between them at the very center of the composition. Every muscle in both figures is rendered with careful anatomical precision, giving the moment of divine creation a sense of powerful, coiled physical potential rather than gentle softness."
    },
    {
        "id": 91, "title": "The Sistine Madonna", "artist": "Raphael", "year": "1512",
        "style": "High Renaissance", "museum": "Gemäldegalerie Alte Meister, Dresden",
        "colors": "Soft green curtains, warm skin tones, pale blue-grey clouds",
        "description": "The Virgin Mary steps forward barefoot through parted green curtains, cradling the Christ child in her arms, both surrounded by countless faint, ghostly cherub faces dissolving into the soft clouds beneath their feet. Two saints kneel on either side of her, one gesturing toward the viewer, while at the very bottom of the painting, two famous winged cherubs lean on a ledge, chins resting on their folded arms, gazing upward with bored, wistful expressions. The soft, muted palette and gentle, forward-stepping pose give the whole composition an intimate, approachable warmth despite its grand religious subject."
    },
    {
        "id": 92, "title": "The Night Café's Companion: Sunflowers Series (Third Version)", "artist": "Vincent van Gogh", "year": "1889",
        "style": "Post-Impressionism", "museum": "Van Gogh Museum, Amsterdam",
        "colors": "Warm gold and amber tones, deep green vase",
        "description": "A simpler bunch of sunflowers stands in a rounded green vase against a flat, warm gold background, the flowers themselves rendered in thick, confident strokes ranging from bright lemon yellow to deep amber and brown at their drying centers. Unlike a busier bouquet, this version has fewer blooms, giving each individual flower head more space and weight on the canvas. The overall warmth of the nearly monochromatic gold and amber palette creates a simple, sturdy, almost domestic sense of quiet abundance."
    },
    {
        "id": 93, "title": "The Tower of the Blue Horses", "artist": "Franz Marc", "year": "1913",
        "style": "Expressionism", "museum": "Formerly Nationalgalerie, Berlin (lost)",
        "colors": "Vivid cobalt blue horses, warm red-orange mountain background",
        "description": "Four vividly blue horses stand stacked in a tall, totem-like formation against a jagged, warm red and orange mountainous background. Their bodies are simplified into smooth, rounded, almost crystalline shapes, with deep blue chosen deliberately to express calm spirituality rather than any horse's natural coloring. The sharp, angular red mountains behind them create a striking contrast between the cool, gentle blue of the animals and the hot, fractured energy of the landscape surrounding them."
    },
    {
        "id": 94, "title": "Composition with Red, Blue and Yellow", "artist": "Piet Mondrian", "year": "1930",
        "style": "De Stijl / Neoplasticism", "museum": "Kunsthaus Zürich",
        "colors": "Pure red, blue, and yellow blocks with white and black grid",
        "description": "A grid of thick, straight black lines divides a white canvas into rectangles of varying size, most left plain white, but three filled solidly with pure primary red, blue, and yellow, positioned asymmetrically rather than evenly. There is no curve, texture, or shading anywhere in the painting, only flat, hard-edged blocks of color and stark black lines. The careful, unequal balance of the colored rectangles against the larger white spaces creates a quiet, orderly visual tension using only the most basic elements of line and primary color."
    },
    {
        "id": 95, "title": "Nighthawks' Companion: Automat", "artist": "Edward Hopper", "year": "1927",
        "style": "American Realism", "museum": "Des Moines Art Center",
        "colors": "Cool teal-green interior, warm amber coat, deep black window",
        "description": "A woman sits alone at a small table in an automat cafeteria late at night, one glove still on, staring down at her cup rather than out at the enormous black window beside her, which reflects only a row of hanging lights receding into darkness. Her warm mustard-colored coat and hat stand out against the cool, teal-green walls and the flat, empty blackness of the window. The quiet, motionless pose and the vast dark window beside her create a strong sense of solitude and late-night stillness."
    },
    {
        "id": 96, "title": "The Fall of Icarus", "artist": "Pieter Bruegel the Elder", "year": "c. 1560",
        "style": "Northern Renaissance", "museum": "Royal Museums of Fine Arts of Belgium",
        "colors": "Warm ochre farmland, soft blue-green sea and sky",
        "description": "A farmer calmly plows a field on a hillside overlooking the sea, entirely absorbed in his own work, while a shepherd nearby tends his flock and a fisherman casts his line along the shore. Only if you look closely near the bottom right corner of the canvas, small, pale, thrashing legs disappear into the water, barely noticeable amid the calm, sunlit landscape, all that remains visible of a boy who has just fallen from the sky. The painting's quiet, everyday warmth throughout emphasizes how easily a mythic tragedy can go completely unnoticed by the ordinary world around it."
    },
    {
        "id": 97, "title": "Portrait of Pope Innocent X", "artist": "Diego Velázquez", "year": "1650",
        "style": "Baroque", "museum": "Doria Pamphilj Gallery, Rome",
        "colors": "Rich scarlet reds, pale stern skin tones",
        "description": "An elderly pope sits rigidly upright in an ornate chair, dressed in layers of rich, glowing scarlet silk and lace, his expression sharp, suspicious, and unflinchingly direct. His pale, weathered face, with its keen, narrowed eyes, is rendered with unusually blunt, unflattering realism rather than the flattering idealization popes typically expected. The deep, saturated reds of his robes and the chair fill most of the canvas, their rich color intensifying the piercing severity of his gaze at the very center of the composition."
    },
    {
        "id": 98, "title": "The Card Players' Companion: Mont Sainte-Victoire", "artist": "Paul Cézanne", "year": "1904",
        "style": "Post-Impressionism", "museum": "Philadelphia Museum of Art",
        "colors": "Cool blue-violet mountain, warm ochre and green foreground",
        "description": "A rugged mountain rises pale blue-violet in the distance under a soft sky, built from small, flat, angular patches of color rather than smooth, blended shading. In front of it, a patchwork of warm green and ochre fields and trees is similarly broken into distinct geometric facets, giving the whole landscape a solid, faceted, almost crystalline structure. Cézanne painted this mountain from the same vantage point many times, each version reducing the natural scene further into these simplified blocks of color and form, treating the landscape almost like a puzzle of shifting planes."
    },
    {
        "id": 99, "title": "Christina's World Companion: The Helga Pictures (Study)", "artist": "Andrew Wyeth", "year": "1970s",
        "style": "American Realism", "museum": "Various collections",
        "colors": "Soft warm skin tones, muted grey-brown interiors",
        "description": "A quiet, contemplative figure sits or reclines in a plain, softly lit interior, rendered in careful, muted tones of grey, brown, and warm skin color with no bright accents to distract from the subject. Every fold of fabric and strand of hair is captured with quiet, patient precision, similar in restrained mood to the artist's more famous windswept field paintings. The overall atmosphere is intimate, still, and unhurried, built from fine detail and soft, even light rather than any dramatic gesture or color."
    },
    {
        "id": 100, "title": "Number 1, 1950 (Lavender Mist)", "artist": "Jackson Pollock", "year": "1950",
        "style": "Abstract Expressionism", "museum": "National Gallery of Art, Washington D.C.",
        "colors": "Soft lavender-grey mist, black, white, and rust accents",
        "description": "A large canvas is covered in a delicate, overlapping web of dripped and flicked paint in white, black, and soft rust, with a faint lavender-grey tone emerging from the overall blend of layered colors. Unlike some of his denser works, the lines here feel airy and open, with more raw canvas showing through between the tangled threads of paint. There is no single shape or focus, only a shimmering, atmospheric haze of fine lines that seems to hover somewhere between solid structure and pure mist."
    },
]
