# -*- coding: utf-8 -*-
"""
Described — backend API
A small Flask service that serves a curated collection of critically
acclaimed paintings, each with a rich, accessible text description
written for listeners who are blind or low-vision.

Endpoints:
  GET /api/paintings                 -> list of all paintings (summary fields)
  GET /api/paintings/<id>            -> full record for one painting
  GET /api/paintings/search?q=...    -> filter by title/artist/style
  GET /api/health                    -> simple health check
"""

from flask import Flask, jsonify, request, send_from_directory
from paintings_data import PAINTINGS

app = Flask(__name__, static_folder="../frontend", static_url_path="")


@app.after_request
def add_cors_headers(response):
    # Permissive CORS so the frontend can be served separately during
    # development (e.g. a static file server) and still call the API.
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response


def summary(p):
    """Lightweight version of a painting record for the gallery grid."""
    return {
        "id": p["id"],
        "title": p["title"],
        "artist": p["artist"],
        "year": p["year"],
        "style": p["style"],
    }


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "count": len(PAINTINGS)})


@app.get("/api/paintings")
def list_paintings():
    return jsonify([summary(p) for p in PAINTINGS])


@app.get("/api/paintings/search")
def search_paintings():
    q = (request.args.get("q") or "").strip().lower()
    if not q:
        return jsonify([summary(p) for p in PAINTINGS])
    results = [
        summary(p) for p in PAINTINGS
        if q in p["title"].lower() or q in p["artist"].lower() or q in p["style"].lower()
    ]
    return jsonify(results)


@app.get("/api/paintings/<int:painting_id>")
def get_painting(painting_id):
    for p in PAINTINGS:
        if p["id"] == painting_id:
            return jsonify(p)
    return jsonify({"error": "Painting not found"}), 404


# Serve the frontend (so the whole app can run from a single Flask process)
@app.get("/")
def serve_index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/<path:path>")
def serve_static(path):
    return send_from_directory(app.static_folder, path)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
