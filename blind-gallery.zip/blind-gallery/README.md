# Described — a gallery you can hear

A small web app that describes 100 critically acclaimed paintings in rich,
accessible language for people who are blind or low-vision — colors,
composition, mood, and style, written to paint a full picture in words.

## Stack
- **Backend:** Python + Flask, serving a REST API over a curated dataset
  (`backend/paintings_data.py`) and the frontend static files.
- **Frontend:** plain HTML/CSS/JavaScript (no build step). Uses the
  browser's built-in **Web Speech API** to read descriptions aloud —
  no external services or API keys needed.

## Run it

```bash
cd backend
pip install -r requirements.txt
python3 app.py
```

Then open **http://127.0.0.1:5000** in a browser.

(The Flask app serves the frontend itself, so you don't need a separate
static server. If you prefer to run the frontend separately, e.g. via
`python3 -m http.server` in `frontend/`, the API already sends permissive
CORS headers.)

## API
- `GET /api/paintings` — list of all 100 paintings (id, title, artist, year, style)
- `GET /api/paintings/<id>` — full record, including museum, palette, and description
- `GET /api/paintings/search?q=...` — filter by title, artist, or style
- `GET /api/health` — status check

## Accessibility design notes
- Every painting is plain, semantic HTML — a screen reader (VoiceOver, NVDA,
  JAWS, TalkBack) reads the full description natively, with no dependency
  on JavaScript speech.
- The **Listening Room** additionally offers an optional "Play description"
  button using `speechSynthesis`, with adjustable reading speed, for
  situations where audio playback (kiosk, kitchen, walking) is preferred
  over a personal screen reader.
- Full keyboard support: `Space` play/pause, `S` stop, `←/→` previous/next
  painting, `Esc` back to the gallery. A skip link jumps straight to the
  collection. Focus is visibly indicated everywhere (`:focus-visible`).
- Respects `prefers-reduced-motion` (disables the pulsing play-button
  animation) and uses a high-contrast dark palette throughout.

## Extending the collection
Add more entries to `PAINTINGS` in `backend/paintings_data.py` — each needs
`id`, `title`, `artist`, `year`, `style`, `museum`, `colors`, and a written
`description`. No other code changes are needed.
